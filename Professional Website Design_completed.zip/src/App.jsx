import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

// pages (most of these exist as .jsx in your project)
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Solutions from './pages/Solutions';
import Portfolio from './pages/Portfolio';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Pricing from './pages/Pricing';
import Payment from './pages/Payment';
import Contact from './pages/Contact';
import Login from './pages/Login';
import Register from './pages/Register';
import GoogleVerification from './pages/GoogleVerification';

export default function App() {
  return (
    <div className="app-root">
      <Navbar />
      <main style={{ minHeight: '70vh', padding: '2rem' }}>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/about" element={<About/>} />
          <Route path="/services" element={<Services/>} />
          <Route path="/solutions" element={<Solutions/>} />
          <Route path="/portfolio" element={<Portfolio/>} />
          <Route path="/products" element={<Products/>} />
          <Route path="/product/:id" element={<ProductDetail/>} />
          <Route path="/pricing" element={<Pricing/>} />
          <Route path="/payment" element={<Payment/>} />
          <Route path="/contact" element={<Contact/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/register" element={<Register/>} />
          <Route path="/gverify" element={<GoogleVerification/>} />
          <Route path="*" element={<Home/>} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
