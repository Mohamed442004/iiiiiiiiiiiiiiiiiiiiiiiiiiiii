import { Link } from 'react-router-dom';
import { ArrowRight, Code, Cloud, Shield, Network, Users, Award, HeadphonesIcon, TrendingUp, CheckCircle2, Zap, BarChart } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';
import Hero3D from '../components/Hero3D';
import ScrollAnimation from '../components/ScrollAnimation';

export default function Home() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);

  const features = [
    {
      icon: Users,
      title: t('home.about.feature1Title'),
      desc: t('home.about.feature1Desc'),
    },
    {
      icon: Zap,
      title: t('home.about.feature2Title'),
      desc: t('home.about.feature2Desc'),
    },
    {
      icon: HeadphonesIcon,
      title: t('home.about.feature3Title'),
      desc: t('home.about.feature3Desc'),
    },
    {
      icon: Award,
      title: t('home.about.feature4Title'),
      desc: t('home.about.feature4Desc'),
    },
  ];

  const services = [
    {
      icon: Code,
      title: t('home.services.service1'),
      desc: t('home.services.service1Desc'),
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Cloud,
      title: t('home.services.service2'),
      desc: t('home.services.service2Desc'),
      color: 'from-cyan-500 to-teal-500',
    },
    {
      icon: Shield,
      title: t('home.services.service3'),
      desc: t('home.services.service3Desc'),
      color: 'from-teal-500 to-green-500',
    },
    {
      icon: Network,
      title: t('home.services.service4'),
      desc: t('home.services.service4Desc'),
      color: 'from-blue-600 to-indigo-600',
    },
  ];

  const stats = [
    { label: t('home.stats.clients'), value: '500+' },
    { label: t('home.stats.projects'), value: '1,200+' },
    { label: t('home.stats.support'), value: '50,000+' },
    { label: t('home.stats.satisfaction'), value: '98%' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-[#F7FAFF] via-blue-50 to-cyan-50">
        {/* 3D Background */}
        <div className="absolute inset-0 opacity-60">
          <Hero3D />
        </div>

        {/* Content */}
        <div className="container relative z-10 mx-auto px-4 py-32">
          <div className="max-w-4xl mx-auto text-center">
            <ScrollAnimation animation="fade-down">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-[#0059C8]/20 mb-8">
                <span className="w-2 h-2 bg-[#00C0F0] rounded-full animate-pulse"></span>
                <span className="text-sm text-[#0059C8] font-medium">
                  Leading IT Solutions Provider
                </span>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="fade-up" delay={100}>
              <h1 className="mb-6">
                {t('home.hero.title')}<br />
                <span className="bg-gradient-to-r from-[#0059C8] to-[#00C0F0] bg-clip-text text-transparent">
                  {t('home.hero.titleHighlight')}
                </span>
              </h1>
            </ScrollAnimation>

            <ScrollAnimation animation="fade-up" delay={200}>
              <p className="text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
                {t('home.hero.subtitle')}
              </p>
            </ScrollAnimation>

            <ScrollAnimation animation="fade-up" delay={300}>
              <div className="flex flex-wrap items-center justify-center gap-4">
                <Link
                  to="/contact"
                  className="btn-primary inline-flex items-center gap-2 group"
                >
                  {t('home.hero.cta1')}
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link to="/services" className="btn-secondary">
                  {t('home.hero.cta2')}
                </Link>
              </div>
            </ScrollAnimation>

            {/* Floating Cards */}
            <ScrollAnimation animation="scale" delay={400}>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20">
                {[
                  { icon: TrendingUp, text: 'Business Growth', color: 'text-[#0059C8]' },
                  { icon: Shield, text: 'Secure Solutions', color: 'text-[#00C0F0]' },
                  { icon: Award, text: 'Award Winning', color: 'text-[#1F4A7A]' },
                ].map((item, index) => (
                  <div
                    key={index}
                    className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-white shadow-lg hover:shadow-xl transition-all hover:-translate-y-2"
                  >
                    <item.icon className={`w-8 h-8 ${item.color} mb-3 mx-auto`} />
                    <p className="font-medium text-[#1A1A1A]">{item.text}</p>
                  </div>
                ))}
              </div>
            </ScrollAnimation>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-[#0059C8] rounded-full flex items-start justify-center p-2">
            <div className="w-1 h-3 bg-[#0059C8] rounded-full"></div>
          </div>
        </div>
      </section>

      {/* About Preview Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center mb-16">
              <h2 className="mb-4">{t('home.about.title')}</h2>
              <p className="text-xl max-w-2xl mx-auto">
                {t('home.about.subtitle')}
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <ScrollAnimation key={index} animation="fade-up" delay={index * 100}>
                <div className="group bg-gradient-to-br from-white to-blue-50 rounded-2xl p-8 border border-gray-100 hover:border-[#0059C8]/30 hover:shadow-xl transition-all hover:-translate-y-2">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#0059C8] to-[#00C0F0] rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <feature.icon className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="mb-3">{feature.title}</h4>
                  <p className="text-sm leading-relaxed">{feature.desc}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-gradient-to-br from-[#F7FAFF] to-blue-50">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center mb-16">
              <h2 className="mb-4">{t('home.services.title')}</h2>
              <p className="text-xl max-w-2xl mx-auto">
                {t('home.services.subtitle')}
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <ScrollAnimation key={index} animation="fade-up" delay={index * 100}>
                <div className="group bg-white rounded-2xl p-8 shadow-md hover:shadow-2xl transition-all hover:-translate-y-2">
                  <div className={`w-14 h-14 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <service.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="mb-3">{service.title}</h3>
                  <p className="mb-6">{service.desc}</p>
                  <Link
                    to="/services"
                    className="inline-flex items-center gap-2 text-[#0059C8] font-medium hover:gap-3 transition-all"
                  >
                    Learn More <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </ScrollAnimation>
            ))}
          </div>

          <ScrollAnimation animation="fade-up" delay={400}>
            <div className="text-center mt-12">
              <Link to="/services" className="btn-primary">
                View All Services
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 bg-gradient-to-br from-[#0059C8] to-[#1F4A7A] text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)',
            backgroundSize: '50px 50px'
          }}></div>
        </div>
        
        <div className="container relative mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <h2 className="text-center mb-16 text-white">{t('home.stats.title')}</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <ScrollAnimation key={index} animation="scale" delay={index * 100}>
                <div className="text-center">
                  <div className="text-5xl md:text-6xl font-bold mb-3 bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
                    {stat.value}
                  </div>
                  <p className="text-blue-100 text-lg">{stat.label}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="scale">
            <div className="max-w-4xl mx-auto bg-gradient-to-br from-[#0059C8] to-[#00C0F0] rounded-3xl p-12 md:p-16 text-center text-white relative overflow-hidden">
              <div className="absolute inset-0 opacity-10">
                <div className="absolute inset-0" style={{
                  backgroundImage: 'linear-gradient(45deg, white 25%, transparent 25%, transparent 75%, white 75%, white), linear-gradient(45deg, white 25%, transparent 25%, transparent 75%, white 75%, white)',
                  backgroundSize: '60px 60px',
                  backgroundPosition: '0 0, 30px 30px'
                }}></div>
              </div>
              
              <div className="relative">
                <h2 className="mb-6 text-white">{t('home.cta.title')}</h2>
                <p className="text-xl mb-10 text-blue-50 max-w-2xl mx-auto">
                  {t('home.cta.subtitle')}
                </p>
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-2 px-8 py-4 bg-white text-[#0059C8] font-semibold rounded-xl hover:shadow-2xl transition-all hover:-translate-y-1 group"
                >
                  {t('home.cta.button')}
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
}
