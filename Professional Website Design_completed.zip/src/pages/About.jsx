import { Target, Eye, Heart, Lightbulb, Shield, Users as UsersIcon } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';
import ScrollAnimation from '../components/ScrollAnimation';

export default function About() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);

  const values = [
    {
      icon: Target,
      title: t('about.values.value1'),
      desc: t('about.values.value1Desc'),
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Lightbulb,
      title: t('about.values.value2'),
      desc: t('about.values.value2Desc'),
      color: 'from-cyan-500 to-teal-500',
    },
    {
      icon: Shield,
      title: t('about.values.value3'),
      desc: t('about.values.value3Desc'),
      color: 'from-teal-500 to-green-500',
    },
    {
      icon: UsersIcon,
      title: t('about.values.value4'),
      desc: t('about.values.value4Desc'),
      color: 'from-blue-600 to-indigo-600',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-gradient-to-br from-[#F7FAFF] via-blue-50 to-cyan-50 overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle, #0059C8 1px, transparent 1px)',
            backgroundSize: '40px 40px'
          }}></div>
        </div>
        
        <div className="container relative mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center max-w-3xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0059C8]/20 mb-6">
                <span className="w-2 h-2 bg-[#00C0F0] rounded-full animate-pulse"></span>
                <span className="text-sm text-[#0059C8] font-medium">About TechNova</span>
              </div>
              <h1 className="mb-6">{t('about.hero.title')}</h1>
              <p className="text-xl">{t('about.hero.subtitle')}</p>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            <ScrollAnimation animation="fade-right">
              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-3xl p-10 border border-blue-100">
                <div className="w-16 h-16 bg-gradient-to-br from-[#0059C8] to-[#00C0F0] rounded-2xl flex items-center justify-center mb-6">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <h3 className="mb-4">{t('about.mission.title')}</h3>
                <p className="leading-relaxed">{t('about.mission.text')}</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="fade-left" delay={100}>
              <div className="bg-gradient-to-br from-cyan-50 to-teal-50 rounded-3xl p-10 border border-cyan-100">
                <div className="w-16 h-16 bg-gradient-to-br from-[#00C0F0] to-[#1F4A7A] rounded-2xl flex items-center justify-center mb-6">
                  <Eye className="w-8 h-8 text-white" />
                </div>
                <h3 className="mb-4">{t('about.vision.title')}</h3>
                <p className="leading-relaxed">{t('about.vision.text')}</p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-24 bg-gradient-to-br from-[#F7FAFF] to-blue-50">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center mb-16">
              <h2 className="mb-4">{t('about.values.title')}</h2>
              <p className="text-xl max-w-2xl mx-auto">
                Core principles that guide everything we do at TechNova
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <ScrollAnimation key={index} animation="fade-up" delay={index * 100}>
                <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all hover:-translate-y-2 group">
                  <div className={`w-14 h-14 bg-gradient-to-br ${value.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <value.icon className="w-7 h-7 text-white" />
                  </div>
                  <h4 className="mb-3">{value.title}</h4>
                  <p className="text-sm leading-relaxed">{value.desc}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <ScrollAnimation animation="fade-up">
              <div className="text-center mb-12">
                <h2 className="mb-6">{t('about.story.title')}</h2>
                <p className="text-xl leading-relaxed">{t('about.story.text')}</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="fade-up" delay={200}>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16">
                {[
                  { year: '2018', label: 'Founded' },
                  { year: '50+', label: 'Team Members' },
                  { year: '15+', label: 'Countries' },
                  { year: '500+', label: 'Clients' },
                ].map((item, index) => (
                  <div key={index} className="text-center">
                    <div className="text-4xl font-bold text-[#0059C8] mb-2">{item.year}</div>
                    <div className="text-sm text-[#555]">{item.label}</div>
                  </div>
                ))}
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-24 bg-gradient-to-br from-[#0059C8] to-[#1F4A7A] text-white">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center max-w-3xl mx-auto">
              <h2 className="mb-6 text-white">Meet Our Expert Team</h2>
              <p className="text-xl text-blue-100 mb-12">
                Dedicated professionals committed to delivering excellence in every project
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <div className="px-6 py-3 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
                  <div className="text-2xl font-bold">50+</div>
                  <div className="text-sm text-blue-100">Certified Experts</div>
                </div>
                <div className="px-6 py-3 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
                  <div className="text-2xl font-bold">15+</div>
                  <div className="text-sm text-blue-100">Years Experience</div>
                </div>
                <div className="px-6 py-3 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
                  <div className="text-2xl font-bold">100+</div>
                  <div className="text-sm text-blue-100">Certifications</div>
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
}
