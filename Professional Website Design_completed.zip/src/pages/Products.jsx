import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, SlidersHorizontal, Star, ShoppingCart } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';
import ScrollAnimation from '../components/ScrollAnimation';
import { products } from '../data/products';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function Products() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Networking', 'Servers', 'Computers'];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-24 bg-gradient-to-br from-[#F7FAFF] via-blue-50 to-cyan-50">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center max-w-3xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0059C8]/20 mb-6">
                <span className="w-2 h-2 bg-[#00C0F0] rounded-full animate-pulse"></span>
                <span className="text-sm text-[#0059C8] font-medium">IT Products</span>
              </div>
              <h1 className="mb-6">{t('products.hero.title')}</h1>
              <p className="text-xl">{t('products.hero.subtitle')}</p>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-white border-b border-gray-200 sticky top-20 z-40">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
              />
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-5 py-2 rounded-lg font-medium transition-all ${
                    selectedCategory === category
                      ? 'bg-[#0059C8] text-white shadow-md'
                      : 'bg-gray-100 text-[#555] hover:bg-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          {filteredProducts.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-xl text-[#555]">No products found matching your criteria</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map((product, index) => (
                <ScrollAnimation key={product.id} animation="fade-up" delay={index * 50}>
                  <div className="group bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-2xl transition-all hover:-translate-y-2">
                    <Link to={`/products/${product.id}`} className="block">
                      <div className="relative h-64 bg-gray-100 overflow-hidden">
                        <ImageWithFallback
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                        {product.inStock ? (
                          <span className="absolute top-4 right-4 px-3 py-1 bg-green-500 text-white text-xs font-medium rounded-full">
                            In Stock
                          </span>
                        ) : (
                          <span className="absolute top-4 right-4 px-3 py-1 bg-red-500 text-white text-xs font-medium rounded-full">
                            Out of Stock
                          </span>
                        )}
                      </div>
                    </Link>

                    <div className="p-6">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="px-2 py-1 bg-blue-50 text-[#0059C8] text-xs font-medium rounded">
                          {product.category}
                        </span>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                          <span className="text-sm font-medium">{product.rating}</span>
                          <span className="text-xs text-gray-500">({product.reviews})</span>
                        </div>
                      </div>

                      <Link to={`/products/${product.id}`}>
                        <h4 className="mb-2 hover:text-[#0059C8] transition-colors">
                          {product.name}
                        </h4>
                      </Link>

                      <p className="text-sm text-[#555] mb-4 line-clamp-2">
                        {product.description}
                      </p>

                      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                        <div>
                          <div className="text-2xl font-bold text-[#0059C8]">
                            ${product.price.toLocaleString()}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Link
                            to={`/products/${product.id}`}
                            className="px-4 py-2 bg-gray-100 text-[#555] font-medium rounded-lg hover:bg-gray-200 transition-colors text-sm"
                          >
                            {t('products.viewDetails')}
                          </Link>
                          <button className="px-4 py-2 bg-[#0059C8] text-white rounded-lg hover:bg-[#004399] transition-colors flex items-center gap-2">
                            <ShoppingCart className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </ScrollAnimation>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
