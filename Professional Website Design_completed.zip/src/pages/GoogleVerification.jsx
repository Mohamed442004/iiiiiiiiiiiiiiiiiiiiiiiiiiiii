import { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, ArrowLeft } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';

export default function GoogleVerification() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);
  const navigate = useNavigate();
  
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const inputRefs = useRef([]);

  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  const handleChange = (index, value) => {
    if (value.length > 1) {
      value = value[0];
    }

    const newCode = [...code];
    newCode[index] = value;
    setCode(newCode);

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const verificationCode = code.join('');
    if (verificationCode.length === 6) {
      alert('Verification successful! (Demo only)');
      navigate('/');
    } else {
      alert('Please enter the complete verification code');
    }
  };

  const handleResend = () => {
    alert('Verification code resent! (Demo only)');
    setCode(['', '', '', '', '', '']);
    inputRefs.current[0]?.focus();
  };

  return (
    <div className="min-h-screen pt-20 flex items-center justify-center bg-gradient-to-br from-[#F7FAFF] via-blue-50 to-cyan-50">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto">
          {/* Back Button */}
          <Link
            to="/login"
            className="inline-flex items-center gap-2 text-[#0059C8] font-medium mb-8 hover:gap-3 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Login
          </Link>

          {/* Logo & Title */}
          <div className="text-center mb-8">
            <Link to="/" className="inline-flex items-center gap-2 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-[#0059C8] to-[#00C0F0] rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-xl">TN</span>
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-[#0059C8] to-[#00C0F0] bg-clip-text text-transparent">
                TechNova
              </span>
            </Link>
            <h2 className="mb-2">{t('auth.verification.title')}</h2>
            <p className="text-[#555]">{t('auth.verification.subtitle')}</p>
          </div>

          {/* Verification Form */}
          <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100">
            {/* Email Icon */}
            <div className="w-16 h-16 bg-gradient-to-br from-[#0059C8] to-[#00C0F0] rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Mail className="w-8 h-8 text-white" />
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Code Input */}
              <div>
                <label className="block text-sm font-medium mb-4 text-center">
                  {t('auth.verification.code')}
                </label>
                <div className="flex gap-2 justify-center">
                  {code.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => (inputRefs.current[index] = el)}
                      type="text"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleChange(index, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      className="w-12 h-14 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                      required
                    />
                  ))}
                </div>
              </div>

              <button type="submit" className="w-full btn-primary justify-center">
                {t('auth.verification.verify')}
              </button>
            </form>

            {/* Resend Link */}
            <div className="text-center mt-6">
              <p className="text-sm text-[#555] mb-2">
                {t('auth.verification.didntReceive')}
              </p>
              <button
                type="button"
                onClick={handleResend}
                className="text-sm text-[#0059C8] font-medium hover:underline"
              >
                {t('auth.verification.resend')}
              </button>
            </div>

            {/* Info Box */}
            <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-100">
              <p className="text-sm text-[#555] text-center">
                Check your Gmail inbox for the verification code. It may take a few moments to arrive.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
