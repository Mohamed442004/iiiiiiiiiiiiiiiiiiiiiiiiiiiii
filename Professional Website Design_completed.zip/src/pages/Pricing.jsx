import { useState } from 'react';
import { Check, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';
import ScrollAnimation from '../components/ScrollAnimation';

export default function Pricing() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);
  const [billingCycle, setBillingCycle] = useState('monthly');

  const plans = [
    {
      name: t('pricing.starter.name'),
      price: billingCycle === 'monthly' ? '$299' : '$2,990',
      period: billingCycle === 'monthly' ? t('pricing.perMonth') : '/year',
      desc: t('pricing.starter.desc'),
      features: t('pricing.starter.features'),
      popular: false,
      color: 'from-blue-500 to-cyan-500',
    },
    {
      name: t('pricing.professional.name'),
      price: billingCycle === 'monthly' ? '$799' : '$7,990',
      period: billingCycle === 'monthly' ? t('pricing.perMonth') : '/year',
      desc: t('pricing.professional.desc'),
      features: t('pricing.professional.features'),
      popular: true,
      color: 'from-cyan-500 to-teal-500',
    },
    {
      name: t('pricing.enterprise.name'),
      price: t('pricing.enterprise.price'),
      period: '',
      desc: t('pricing.enterprise.desc'),
      features: t('pricing.enterprise.features'),
      popular: false,
      color: 'from-teal-500 to-green-500',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-24 bg-gradient-to-br from-[#F7FAFF] via-blue-50 to-cyan-50">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center max-w-3xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0059C8]/20 mb-6">
                <span className="w-2 h-2 bg-[#00C0F0] rounded-full animate-pulse"></span>
                <span className="text-sm text-[#0059C8] font-medium">Pricing Plans</span>
              </div>
              <h1 className="mb-6">{t('pricing.hero.title')}</h1>
              <p className="text-xl mb-8">{t('pricing.hero.subtitle')}</p>

              {/* Billing Toggle */}
              <div className="inline-flex items-center gap-4 p-2 bg-white rounded-xl border border-gray-200 shadow-sm">
                <button
                  onClick={() => setBillingCycle('monthly')}
                  className={`px-6 py-2 rounded-lg font-medium transition-all ${
                    billingCycle === 'monthly'
                      ? 'bg-[#0059C8] text-white'
                      : 'text-[#555] hover:bg-gray-50'
                  }`}
                >
                  {t('pricing.monthly')}
                </button>
                <button
                  onClick={() => setBillingCycle('yearly')}
                  className={`px-6 py-2 rounded-lg font-medium transition-all ${
                    billingCycle === 'yearly'
                      ? 'bg-[#0059C8] text-white'
                      : 'text-[#555] hover:bg-gray-50'
                  }`}
                >
                  {t('pricing.yearly')}
                  <span className="ml-2 text-xs bg-green-500 text-white px-2 py-0.5 rounded-full">
                    Save 15%
                  </span>
                </button>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan, index) => (
              <ScrollAnimation key={index} animation="fade-up" delay={index * 100}>
                <div
                  className={`relative rounded-3xl p-8 border-2 transition-all hover:shadow-2xl hover:-translate-y-2 ${
                    plan.popular
                      ? 'border-[#0059C8] bg-gradient-to-br from-white to-blue-50'
                      : 'border-gray-200 bg-white'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <span className="px-4 py-1 bg-[#0059C8] text-white text-sm font-medium rounded-full shadow-lg">
                        {t('pricing.popular')}
                      </span>
                    </div>
                  )}

                  <div className={`w-14 h-14 bg-gradient-to-br ${plan.color} rounded-xl flex items-center justify-center mb-6`}>
                    <div className="w-6 h-6 bg-white rounded-lg"></div>
                  </div>

                  <h3 className="mb-2">{plan.name}</h3>
                  <p className="text-sm text-[#555] mb-6">{plan.desc}</p>

                  <div className="mb-6">
                    <span className="text-5xl font-bold text-[#0059C8]">{plan.price}</span>
                    {plan.period && <span className="text-[#555] ml-2">{plan.period}</span>}
                  </div>

                  <Link
                    to="/contact"
                    className={`w-full flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all hover:-translate-y-0.5 mb-8 ${
                      plan.popular
                        ? 'bg-[#0059C8] text-white hover:bg-[#004399] shadow-lg hover:shadow-xl'
                        : 'bg-gray-100 text-[#0059C8] hover:bg-gray-200'
                    }`}
                  >
                    {t('pricing.selectPlan')}
                    <ArrowRight className="w-4 h-4" />
                  </Link>

                  <ul className="space-y-4">
                    {plan.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-start gap-3">
                        <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Check className="w-3 h-3 text-green-600" />
                        </div>
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ / CTA */}
      <section className="py-24 bg-gradient-to-br from-[#0059C8] to-[#1F4A7A] text-white">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="scale">
            <div className="text-center max-w-3xl mx-auto">
              <h2 className="mb-6 text-white">Need a Custom Plan?</h2>
              <p className="text-xl text-blue-100 mb-10">
                We can create a tailored solution that perfectly fits your organization's needs
              </p>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-8 py-4 bg-white text-[#0059C8] font-semibold rounded-xl hover:shadow-2xl transition-all hover:-translate-y-1"
              >
                Contact Sales
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
}
