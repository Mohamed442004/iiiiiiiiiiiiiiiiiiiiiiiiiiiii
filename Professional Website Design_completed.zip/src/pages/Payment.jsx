import { useState } from 'react';
import { CreditCard, Shield, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';
import ScrollAnimation from '../components/ScrollAnimation';

export default function Payment() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);
  
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [formData, setFormData] = useState({
    cardNumber: '',
    cardName: '',
    expiry: '',
    cvv: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Payment processed successfully! (Demo only)');
  };

  const orderItems = [
    { name: 'Enterprise Network Router Pro', price: 1299.99 },
  ];

  const subtotal = orderItems.reduce((sum, item) => sum + item.price, 0);
  const tax = subtotal * 0.14; // 14% tax
  const total = subtotal + tax;

  return (
    <div className="min-h-screen pt-20 bg-gradient-to-br from-[#F7FAFF] to-blue-50">
      <section className="py-16">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="max-w-5xl mx-auto">
              <h1 className="mb-8 text-center">{t('payment.title')}</h1>

              <div className="grid lg:grid-cols-3 gap-8">
                {/* Payment Form */}
                <div className="lg:col-span-2">
                  <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
                    <h3 className="mb-6">{t('payment.method')}</h3>

                    {/* Payment Method Selector */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
                      <button
                        onClick={() => setPaymentMethod('card')}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          paymentMethod === 'card'
                            ? 'border-[#0059C8] bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <CreditCard className="w-8 h-8 mx-auto mb-2 text-[#0059C8]" />
                        <div className="text-xs font-medium">Card</div>
                      </button>

                      <button
                        onClick={() => setPaymentMethod('instapay')}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          paymentMethod === 'instapay'
                            ? 'border-[#0059C8] bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="w-8 h-8 mx-auto mb-2 bg-gradient-to-br from-[#0059C8] to-[#00C0F0] rounded-lg flex items-center justify-center">
                          <span className="text-white font-bold text-xs">IP</span>
                        </div>
                        <div className="text-xs font-medium">InstaPay</div>
                      </button>

                      <button
                        onClick={() => setPaymentMethod('vodafone')}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          paymentMethod === 'vodafone'
                            ? 'border-[#0059C8] bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="w-8 h-8 mx-auto mb-2 bg-red-600 rounded-lg flex items-center justify-center">
                          <span className="text-white font-bold text-xs">VC</span>
                        </div>
                        <div className="text-xs font-medium">Vodafone</div>
                      </button>

                      <button
                        onClick={() => setPaymentMethod('mastercard')}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          paymentMethod === 'mastercard'
                            ? 'border-[#0059C8] bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="w-8 h-8 mx-auto mb-2 bg-orange-500 rounded-lg flex items-center justify-center">
                          <span className="text-white font-bold text-xs">MC</span>
                        </div>
                        <div className="text-xs font-medium">Mastercard</div>
                      </button>
                    </div>

                    {/* Payment Form */}
                    <form onSubmit={handleSubmit} className="space-y-6">
                      {(paymentMethod === 'card' || paymentMethod === 'mastercard') && (
                        <>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              {t('payment.cardNumber')}
                            </label>
                            <input
                              type="text"
                              placeholder="1234 5678 9012 3456"
                              value={formData.cardNumber}
                              onChange={(e) => setFormData({ ...formData, cardNumber: e.target.value })}
                              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                              required
                            />
                          </div>

                          <div>
                            <label className="block text-sm font-medium mb-2">
                              {t('payment.cardName')}
                            </label>
                            <input
                              type="text"
                              placeholder="John Doe"
                              value={formData.cardName}
                              onChange={(e) => setFormData({ ...formData, cardName: e.target.value })}
                              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                              required
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium mb-2">
                                {t('payment.expiry')}
                              </label>
                              <input
                                type="text"
                                placeholder="MM/YY"
                                value={formData.expiry}
                                onChange={(e) => setFormData({ ...formData, expiry: e.target.value })}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                                required
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-2">
                                {t('payment.cvv')}
                              </label>
                              <input
                                type="text"
                                placeholder="123"
                                value={formData.cvv}
                                onChange={(e) => setFormData({ ...formData, cvv: e.target.value })}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                                required
                              />
                            </div>
                          </div>
                        </>
                      )}

                      {paymentMethod === 'instapay' && (
                        <div>
                          <label className="block text-sm font-medium mb-2">InstaPay Phone Number</label>
                          <input
                            type="tel"
                            placeholder="+20 123 456 7890"
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                            required
                          />
                        </div>
                      )}

                      {paymentMethod === 'vodafone' && (
                        <div>
                          <label className="block text-sm font-medium mb-2">Vodafone Cash Number</label>
                          <input
                            type="tel"
                            placeholder="+20 123 456 7890"
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                            required
                          />
                        </div>
                      )}

                      <div className="flex items-center gap-2 p-4 bg-blue-50 rounded-xl">
                        <Shield className="w-5 h-5 text-[#0059C8]" />
                        <span className="text-sm text-[#555]">{t('payment.secure')}</span>
                      </div>

                      <button
                        type="submit"
                        className="w-full btn-primary justify-center text-lg py-4"
                      >
                        {t('payment.pay')} ${total.toFixed(2)}
                      </button>
                    </form>
                  </div>
                </div>

                {/* Order Summary */}
                <div className="lg:col-span-1">
                  <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 sticky top-24">
                    <h3 className="mb-6">{t('payment.orderSummary')}</h3>

                    <div className="space-y-4 mb-6 pb-6 border-b border-gray-200">
                      {orderItems.map((item, index) => (
                        <div key={index} className="flex justify-between">
                          <span className="text-sm">{item.name}</span>
                          <span className="text-sm font-medium">${item.price.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-3 mb-6 pb-6 border-b border-gray-200">
                      <div className="flex justify-between text-sm">
                        <span className="text-[#555]">{t('payment.subtotal')}</span>
                        <span className="font-medium">${subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-[#555]">{t('payment.tax')} (14%)</span>
                        <span className="font-medium">${tax.toFixed(2)}</span>
                      </div>
                    </div>

                    <div className="flex justify-between text-xl font-bold mb-6">
                      <span>{t('payment.total')}</span>
                      <span className="text-[#0059C8]">${total.toFixed(2)}</span>
                    </div>

                    <div className="space-y-3 text-sm text-[#555]">
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                        <span>Secure payment processing</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                        <span>Free shipping on orders over $1000</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                        <span>30-day return policy</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
}
