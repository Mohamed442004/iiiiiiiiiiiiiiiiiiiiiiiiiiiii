import { Building2, ShoppingCart, GraduationCap, Hospital, TrendingUp, Users } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';
import ScrollAnimation from '../components/ScrollAnimation';
import { Link } from 'react-router-dom';

export default function Solutions() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);

  const solutions = [
    {
      icon: Building2,
      title: 'Enterprise Solutions',
      desc: 'Comprehensive IT infrastructure and management systems for large organizations',
      features: ['ERP Systems', 'CRM Integration', 'Workflow Automation', 'Advanced Analytics'],
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: ShoppingCart,
      title: 'E-Commerce Platforms',
      desc: 'Full-featured online stores with payment integration and inventory management',
      features: ['Custom Storefront', 'Payment Gateway', 'Inventory System', 'Mobile App'],
      color: 'from-cyan-500 to-teal-500',
    },
    {
      icon: GraduationCap,
      title: 'Education Technology',
      desc: 'Learning management systems and educational platforms for institutions',
      features: ['LMS Platform', 'Virtual Classrooms', 'Student Portal', 'Assessment Tools'],
      color: 'from-teal-500 to-green-500',
    },
    {
      icon: Hospital,
      title: 'Healthcare IT',
      desc: 'Secure and compliant healthcare information systems',
      features: ['Patient Management', 'Electronic Records', 'Appointment System', 'Telemedicine'],
      color: 'from-green-500 to-emerald-500',
    },
    {
      icon: TrendingUp,
      title: 'Business Intelligence',
      desc: 'Data-driven insights and analytics solutions for informed decision making',
      features: ['Dashboard Analytics', 'Real-time Reporting', 'Predictive Models', 'Data Mining'],
      color: 'from-blue-600 to-indigo-600',
    },
    {
      icon: Users,
      title: 'HR Management Systems',
      desc: 'Complete human resource management and employee engagement platforms',
      features: ['Employee Portal', 'Payroll System', 'Performance Tracking', 'Recruitment Tools'],
      color: 'from-indigo-600 to-purple-600',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-24 bg-gradient-to-br from-[#F7FAFF] via-blue-50 to-cyan-50">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center max-w-3xl mx-auto">
              <h1 className="mb-6">Industry Solutions</h1>
              <p className="text-xl">
                Tailored technology solutions designed for your industry's unique needs
              </p>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Solutions Grid */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {solutions.map((solution, index) => (
              <ScrollAnimation key={index} animation="fade-up" delay={index * 100}>
                <div className="group bg-gradient-to-br from-white to-blue-50 rounded-2xl p-8 border border-gray-100 hover:shadow-2xl transition-all hover:-translate-y-2">
                  <div className={`w-14 h-14 bg-gradient-to-br ${solution.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <solution.icon className="w-7 h-7 text-white" />
                  </div>
                  
                  <h4 className="mb-3">{solution.title}</h4>
                  <p className="text-sm mb-6">{solution.desc}</p>
                  
                  <ul className="space-y-2 mb-6">
                    {solution.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-center gap-2 text-sm">
                        <div className="w-1.5 h-1.5 bg-[#00C0F0] rounded-full"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <Link to="/contact" className="text-sm text-[#0059C8] font-medium hover:underline">
                    Learn More →
                  </Link>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-gradient-to-br from-[#F7FAFF] to-blue-50">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="scale">
            <div className="max-w-3xl mx-auto text-center bg-white rounded-3xl p-12 shadow-lg">
              <h2 className="mb-6">Need a Custom Solution?</h2>
              <p className="text-xl mb-8">
                Our team can design and develop tailored solutions for your specific business requirements
              </p>
              <Link to="/contact" className="btn-primary">
                Discuss Your Project
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
}
