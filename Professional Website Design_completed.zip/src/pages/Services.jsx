import { Code, Cloud, Shield, Network, Database, BarChart, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';
import ScrollAnimation from '../components/ScrollAnimation';
import { Link } from 'react-router-dom';

export default function Services() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);

  const services = [
    {
      icon: Code,
      title: t('services.itConsulting.title'),
      desc: t('services.itConsulting.desc'),
      features: t('services.itConsulting.features'),
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Cloud,
      title: t('services.webDevelopment.title'),
      desc: t('services.webDevelopment.desc'),
      features: t('services.webDevelopment.features'),
      color: 'from-cyan-500 to-teal-500',
    },
    {
      icon: Shield,
      title: t('services.cloudServices.title'),
      desc: t('services.cloudServices.desc'),
      features: t('services.cloudServices.features'),
      color: 'from-teal-500 to-green-500',
    },
    {
      icon: Network,
      title: t('services.cybersecurity.title'),
      desc: t('services.cybersecurity.desc'),
      features: t('services.cybersecurity.features'),
      color: 'from-blue-600 to-indigo-600',
    },
    {
      icon: Database,
      title: t('services.networkInfra.title'),
      desc: t('services.networkInfra.desc'),
      features: t('services.networkInfra.features'),
      color: 'from-indigo-600 to-purple-600',
    },
    {
      icon: BarChart,
      title: t('services.dataAnalytics.title'),
      desc: t('services.dataAnalytics.desc'),
      features: t('services.dataAnalytics.features'),
      color: 'from-purple-600 to-pink-600',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-gradient-to-br from-[#F7FAFF] via-blue-50 to-cyan-50">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center max-w-3xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0059C8]/20 mb-6">
                <span className="w-2 h-2 bg-[#00C0F0] rounded-full animate-pulse"></span>
                <span className="text-sm text-[#0059C8] font-medium">Our Services</span>
              </div>
              <h1 className="mb-6">{t('services.hero.title')}</h1>
              <p className="text-xl">{t('services.hero.subtitle')}</p>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {services.map((service, index) => (
              <ScrollAnimation key={index} animation="fade-up" delay={index * 100}>
                <div className="group bg-gradient-to-br from-white to-blue-50 rounded-3xl p-10 border border-gray-100 hover:border-[#0059C8]/30 hover:shadow-2xl transition-all hover:-translate-y-2">
                  <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <service.icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <h3 className="mb-4">{service.title}</h3>
                  <p className="mb-6">{service.desc}</p>
                  
                  <ul className="space-y-3 mb-8">
                    {service.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-[#00C0F0] flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Link
                    to="/contact"
                    className="inline-flex items-center gap-2 text-[#0059C8] font-medium hover:gap-3 transition-all"
                  >
                    Get Started →
                  </Link>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-[#0059C8] to-[#1F4A7A] text-white">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="scale">
            <div className="text-center max-w-3xl mx-auto">
              <h2 className="mb-6 text-white">Ready to Get Started?</h2>
              <p className="text-xl text-blue-100 mb-10">
                Let's discuss how our services can help transform your business
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link to="/contact" className="px-8 py-4 bg-white text-[#0059C8] font-semibold rounded-xl hover:shadow-2xl transition-all hover:-translate-y-1">
                  Contact Us
                </Link>
                <Link to="/pricing" className="px-8 py-4 bg-white/10 border-2 border-white text-white font-semibold rounded-xl hover:bg-white/20 transition-all">
                  View Pricing
                </Link>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
}
