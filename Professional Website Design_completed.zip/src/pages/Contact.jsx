import { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';
import ScrollAnimation from '../components/ScrollAnimation';

export default function Contact() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Message sent successfully! (Demo only)');
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: 'Address',
      details: t('contact.info.address'),
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Phone,
      title: 'Phone',
      details: t('contact.info.phone'),
      color: 'from-cyan-500 to-teal-500',
    },
    {
      icon: Mail,
      title: 'Email',
      details: t('contact.info.email'),
      color: 'from-teal-500 to-green-500',
    },
    {
      icon: Clock,
      title: 'Working Hours',
      details: t('contact.info.hours'),
      color: 'from-blue-600 to-indigo-600',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-24 bg-gradient-to-br from-[#F7FAFF] via-blue-50 to-cyan-50">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center max-w-3xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0059C8]/20 mb-6">
                <span className="w-2 h-2 bg-[#00C0F0] rounded-full animate-pulse"></span>
                <span className="text-sm text-[#0059C8] font-medium">Contact Us</span>
              </div>
              <h1 className="mb-6">{t('contact.hero.title')}</h1>
              <p className="text-xl">{t('contact.hero.subtitle')}</p>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {contactInfo.map((info, index) => (
              <ScrollAnimation key={index} animation="fade-up" delay={index * 100}>
                <div className="bg-gradient-to-br from-white to-blue-50 rounded-2xl p-6 border border-gray-100 hover:shadow-xl transition-all hover:-translate-y-2 group">
                  <div className={`w-12 h-12 bg-gradient-to-br ${info.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <info.icon className="w-6 h-6 text-white" />
                  </div>
                  <h5 className="mb-2">{info.title}</h5>
                  <p className="text-sm text-[#555]">{info.details}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form & Map */}
      <section className="py-16 bg-gradient-to-br from-[#F7FAFF] to-blue-50">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {/* Form */}
            <ScrollAnimation animation="fade-right">
              <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
                <h3 className="mb-6">Send us a Message</h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {t('contact.form.name')}
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                      required
                    />
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        {t('contact.form.email')}
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        {t('contact.form.phone')}
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {t('contact.form.subject')}
                    </label>
                    <input
                      type="text"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {t('contact.form.message')}
                    </label>
                    <textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      rows="5"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0059C8] focus:border-transparent resize-none"
                      required
                    ></textarea>
                  </div>

                  <button type="submit" className="w-full btn-primary justify-center">
                    <Send className="w-5 h-5" />
                    {t('contact.form.send')}
                  </button>
                </form>
              </div>
            </ScrollAnimation>

            {/* Map */}
            <ScrollAnimation animation="fade-left">
              <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 h-full">
                <h3 className="mb-6">Our Location</h3>
                <div className="w-full h-[400px] bg-gradient-to-br from-blue-100 to-cyan-100 rounded-xl flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="w-16 h-16 text-[#0059C8] mx-auto mb-4" />
                    <p className="text-[#555]">Interactive Map</p>
                    <p className="text-sm text-[#777]">123 Business District, Tech Tower</p>
                    <p className="text-sm text-[#777]">Cairo, Egypt</p>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="scale">
            <div className="max-w-4xl mx-auto bg-gradient-to-br from-[#0059C8] to-[#00C0F0] rounded-3xl p-12 text-center text-white">
              <h2 className="mb-6 text-white">Need Immediate Assistance?</h2>
              <p className="text-xl text-blue-50 mb-8">
                Our support team is available 24/7 to help you
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <a
                  href={`tel:${t('contact.info.phone')}`}
                  className="px-8 py-4 bg-white text-[#0059C8] font-semibold rounded-xl hover:shadow-2xl transition-all hover:-translate-y-1"
                >
                  Call Us Now
                </a>
                <a
                  href={`mailto:${t('contact.info.email')}`}
                  className="px-8 py-4 bg-white/10 border-2 border-white text-white font-semibold rounded-xl hover:bg-white/20 transition-all"
                >
                  Send Email
                </a>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
}
