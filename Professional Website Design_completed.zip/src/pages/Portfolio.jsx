import { ExternalLink, Calendar, Tag } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';
import ScrollAnimation from '../components/ScrollAnimation';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function Portfolio() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);

  const projects = [
    {
      title: 'Enterprise Resource Planning System',
      category: 'Enterprise Software',
      description: 'Complete ERP solution for manufacturing company with 500+ employees',
      image: 'https://images.unsplash.com/photo-1573164713988-8665fc963095?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzYzMTg2ODA0fDA&ixlib=rb-4.1.0&q=80&w=1080',
      tags: ['ERP', 'Cloud', 'Database'],
      date: '2024',
    },
    {
      title: 'E-Commerce Platform',
      category: 'Web Development',
      description: 'Multi-vendor marketplace with advanced product management and analytics',
      image: 'https://images.unsplash.com/photo-1649451844931-57e22fc82de3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWIlMjBkZXZlbG9wbWVudCUyMGRhc2hib2FyZHxlbnwxfHx8fDE3NjMxODgwODZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      tags: ['E-Commerce', 'React', 'Payment'],
      date: '2024',
    },
    {
      title: 'Mobile Banking Application',
      category: 'Mobile Development',
      description: 'Secure mobile banking app with biometric authentication',
      image: 'https://images.unsplash.com/photo-1609921212029-bb5a28e60960?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBkZXNpZ258ZW58MXx8fHwxNzYzMTg0MTI4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      tags: ['Mobile', 'Security', 'FinTech'],
      date: '2023',
    },
    {
      title: 'Healthcare Management System',
      category: 'Healthcare IT',
      description: 'Complete hospital management system with patient portal and telemedicine',
      image: 'https://images.unsplash.com/photo-1573164713988-8665fc963095?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzYzMTg2ODA0fDA&ixlib=rb-4.1.0&q=80&w=1080',
      tags: ['Healthcare', 'HIPAA', 'Cloud'],
      date: '2023',
    },
    {
      title: 'Learning Management Platform',
      category: 'Education Technology',
      description: 'Online learning platform serving 10,000+ students',
      image: 'https://images.unsplash.com/photo-1649451844931-57e22fc82de3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWIlMjBkZXZlbG9wbWVudCUyMGRhc2hib2FyZHxlbnwxfHx8fDE3NjMxODgwODZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      tags: ['Education', 'LMS', 'Video'],
      date: '2023',
    },
    {
      title: 'IoT Monitoring Dashboard',
      category: 'IoT Solutions',
      description: 'Real-time monitoring and analytics for smart city infrastructure',
      image: 'https://images.unsplash.com/photo-1748346918817-0b1b6b2f9bab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBvZmZpY2UlMjB0ZWFtJTIwd29ya2luZ3xlbnwxfHx8fDE3NjMxMjYzMjd8MA&ixlib=rb-4.1.0&q=80&w=1080',
      tags: ['IoT', 'Real-time', 'Analytics'],
      date: '2024',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-24 bg-gradient-to-br from-[#F7FAFF] via-blue-50 to-cyan-50">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="fade-up">
            <div className="text-center max-w-3xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full border border-[#0059C8]/20 mb-6">
                <span className="w-2 h-2 bg-[#00C0F0] rounded-full animate-pulse"></span>
                <span className="text-sm text-[#0059C8] font-medium">Our Work</span>
              </div>
              <h1 className="mb-6">Portfolio</h1>
              <p className="text-xl">
                Explore our successful projects across various industries
              </p>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <ScrollAnimation key={index} animation="fade-up" delay={index * 100}>
                <div className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-2xl transition-all hover:-translate-y-2">
                  <div className="relative h-64 overflow-hidden bg-gray-100">
                    <ImageWithFallback
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute top-4 right-4">
                      <span className="px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-medium text-[#0059C8]">
                        {project.category}
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <div className="flex items-center gap-2 text-xs text-[#777] mb-3">
                      <Calendar className="w-4 h-4" />
                      {project.date}
                    </div>
                    
                    <h4 className="mb-3">{project.title}</h4>
                    <p className="text-sm mb-4 text-[#555]">{project.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.map((tag, tIndex) => (
                        <span key={tIndex} className="px-2 py-1 bg-blue-50 text-[#0059C8] rounded text-xs font-medium">
                          {tag}
                        </span>
                      ))}
                    </div>
                    
                    <button className="flex items-center gap-2 text-sm text-[#0059C8] font-medium hover:gap-3 transition-all">
                      View Case Study <ExternalLink className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-gradient-to-br from-[#0059C8] to-[#1F4A7A] text-white">
        <div className="container mx-auto px-4">
          <ScrollAnimation animation="scale">
            <div className="text-center max-w-3xl mx-auto">
              <h2 className="mb-6 text-white">Let's Build Something Amazing Together</h2>
              <p className="text-xl text-blue-100 mb-10">
                Ready to start your project? Get in touch with our team today
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <a href="/contact" className="px-8 py-4 bg-white text-[#0059C8] font-semibold rounded-xl hover:shadow-2xl transition-all hover:-translate-y-1">
                  Start Your Project
                </a>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
}
