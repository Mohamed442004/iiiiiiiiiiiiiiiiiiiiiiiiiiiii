import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, ShoppingCart, Check, ArrowLeft, Heart } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { getTranslation } from '../translations';
import ScrollAnimation from '../components/ScrollAnimation';
import { products } from '../data/products';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function ProductDetail() {
  const { id } = useParams();
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);
  
  const product = products.find(p => p.id === parseInt(id));
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center">
          <h2 className="mb-4">Product Not Found</h2>
          <Link to="/products" className="btn-primary">
            Back to Products
          </Link>
        </div>
      </div>
    );
  }

  const relatedProducts = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 3);

  return (
    <div className="min-h-screen pt-20">
      {/* Breadcrumb */}
      <section className="py-6 bg-gray-50 border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2 text-sm">
            <Link to="/" className="text-[#555] hover:text-[#0059C8]">Home</Link>
            <span className="text-gray-400">/</span>
            <Link to="/products" className="text-[#555] hover:text-[#0059C8]">Products</Link>
            <span className="text-gray-400">/</span>
            <span className="text-[#0059C8] font-medium">{product.name}</span>
          </div>
        </div>
      </section>

      {/* Product Detail */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <Link to="/products" className="inline-flex items-center gap-2 text-[#0059C8] font-medium mb-8 hover:gap-3 transition-all">
            <ArrowLeft className="w-4 h-4" />
            Back to Products
          </Link>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Gallery */}
            <ScrollAnimation animation="fade-right">
              <div>
                <div className="bg-gray-100 rounded-2xl overflow-hidden mb-4 aspect-square">
                  <ImageWithFallback
                    src={product.gallery[selectedImage]}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="grid grid-cols-4 gap-4">
                  {product.gallery.map((img, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImage(index)}
                      className={`aspect-square bg-gray-100 rounded-lg overflow-hidden border-2 transition-all ${
                        selectedImage === index ? 'border-[#0059C8]' : 'border-transparent hover:border-gray-300'
                      }`}
                    >
                      <ImageWithFallback
                        src={img}
                        alt={`${product.name} ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>
            </ScrollAnimation>

            {/* Info */}
            <ScrollAnimation animation="fade-left">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 bg-blue-50 text-[#0059C8] text-sm font-medium rounded-full">
                    {product.category}
                  </span>
                  {product.inStock && (
                    <span className="px-3 py-1 bg-green-50 text-green-600 text-sm font-medium rounded-full flex items-center gap-1">
                      <Check className="w-4 h-4" /> In Stock
                    </span>
                  )}
                </div>

                <h1 className="mb-4">{product.name}</h1>

                <div className="flex items-center gap-4 mb-6">
                  <div className="flex items-center gap-2">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${
                          i < Math.floor(product.rating)
                            ? 'text-yellow-400 fill-yellow-400'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                    <span className="font-medium">{product.rating}</span>
                  </div>
                  <span className="text-[#555]">({product.reviews} reviews)</span>
                </div>

                <div className="text-4xl font-bold text-[#0059C8] mb-6">
                  ${product.price.toLocaleString()}
                </div>

                <p className="text-lg mb-8 leading-relaxed">{product.description}</p>

                {/* Quantity & Add to Cart */}
                <div className="flex flex-wrap gap-4 mb-8 pb-8 border-b border-gray-200">
                  <div className="flex items-center border border-gray-300 rounded-lg">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-4 py-3 hover:bg-gray-50"
                    >
                      -
                    </button>
                    <span className="px-6 py-3 border-x border-gray-300 font-medium">{quantity}</span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-4 py-3 hover:bg-gray-50"
                    >
                      +
                    </button>
                  </div>
                  
                  <Link
                    to="/payment"
                    className="flex-1 btn-primary justify-center"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    {t('products.addToCart')}
                  </Link>

                  <button className="px-5 py-3 border-2 border-gray-300 rounded-lg hover:border-[#0059C8] hover:text-[#0059C8] transition-colors">
                    <Heart className="w-5 h-5" />
                  </button>
                </div>

                {/* Features */}
                <div className="mb-8">
                  <h3 className="mb-4">{t('products.features')}</h3>
                  <ul className="grid sm:grid-cols-2 gap-3">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-[#00C0F0] flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </ScrollAnimation>
          </div>

          {/* Specifications */}
          <ScrollAnimation animation="fade-up">
            <div className="mt-16">
              <h2 className="mb-8">{t('products.specifications')}</h2>
              <div className="bg-gradient-to-br from-white to-blue-50 rounded-2xl p-8 border border-gray-100">
                <div className="grid sm:grid-cols-2 gap-6">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="flex gap-4 pb-4 border-b border-gray-200">
                      <span className="font-semibold text-[#1A1A1A] min-w-[140px]">{key}:</span>
                      <span className="text-[#555]">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </ScrollAnimation>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <ScrollAnimation animation="fade-up">
              <div className="mt-16">
                <h2 className="mb-8">{t('products.relatedProducts')}</h2>
                <div className="grid md:grid-cols-3 gap-8">
                  {relatedProducts.map((relProduct) => (
                    <Link
                      key={relProduct.id}
                      to={`/products/${relProduct.id}`}
                      className="group bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-xl transition-all hover:-translate-y-2"
                    >
                      <div className="relative h-48 bg-gray-100 overflow-hidden">
                        <ImageWithFallback
                          src={relProduct.image}
                          alt={relProduct.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                      </div>
                      <div className="p-6">
                        <h4 className="mb-2">{relProduct.name}</h4>
                        <div className="text-xl font-bold text-[#0059C8]">
                          ${relProduct.price.toLocaleString()}
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </ScrollAnimation>
          )}
        </div>
      </section>
    </div>
  );
}
