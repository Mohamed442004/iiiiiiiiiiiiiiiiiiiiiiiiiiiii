import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar(){
  return (
    <header style={{padding: '1rem 2rem', borderBottom: '1px solid #e6e6e6', display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
      <div style={{fontWeight: 700}}>
        <Link to="/" style={{textDecoration:'none', color:'inherit'}}>TechNova</Link>
      </div>
      <nav>
        <Link to="/" style={{marginRight:16}}>Home</Link>
        <Link to="/services" style={{marginRight:16}}>Services</Link>
        <Link to="/portfolio" style={{marginRight:16}}>Portfolio</Link>
        <Link to="/about" style={{marginRight:16}}>About</Link>
        <Link to="/contact" style={{marginRight:0}}>Contact</Link>
      </nav>
    </header>
  );
}
