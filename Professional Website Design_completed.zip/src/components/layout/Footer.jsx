import { Link } from 'react-router-dom';
import { Facebook, Twitter, Linkedin, Instagram, Mail, Phone, MapPin } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { getTranslation } from '../../translations';

export default function Footer() {
  const { language } = useLanguage();
  const t = (key) => getTranslation(language, key);

  const quickLinks = [
    { path: '/', label: t('nav.home') },
    { path: '/about', label: t('nav.about') },
    { path: '/services', label: t('nav.services') },
    { path: '/portfolio', label: t('nav.portfolio') },
  ];

  const serviceLinks = [
    { path: '/services', label: t('services.itConsulting.title') },
    { path: '/services', label: t('services.webDevelopment.title') },
    { path: '/services', label: t('services.cloudServices.title') },
    { path: '/services', label: t('services.cybersecurity.title') },
  ];

  const companyLinks = [
    { path: '/about', label: t('nav.about') },
    { path: '/contact', label: t('nav.contact') },
    { path: '/pricing', label: t('nav.pricing') },
    { path: '/products', label: t('nav.products') },
  ];

  return (
    <footer className="bg-gradient-to-br from-[#1F4A7A] to-[#0059C8] text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                <span className="text-[#0059C8] font-bold text-xl">TN</span>
              </div>
              <span className="text-2xl font-bold">TechNova</span>
            </div>
            <p className="text-blue-100 text-sm leading-relaxed">
              {t('footer.tagline')}
            </p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-lg flex items-center justify-center transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-lg flex items-center justify-center transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-lg flex items-center justify-center transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/10 hover:bg-white/20 rounded-lg flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">{t('footer.quickLinks')}</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-blue-100 hover:text-white text-sm transition-colors inline-block hover:translate-x-1"
                    style={{ transform: language === 'ar' ? 'translateX(0)' : 'none' }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold mb-4">{t('footer.services')}</h3>
            <ul className="space-y-2">
              {serviceLinks.map((link, index) => (
                <li key={index}>
                  <Link
                    to={link.path}
                    className="text-blue-100 hover:text-white text-sm transition-colors inline-block hover:translate-x-1"
                    style={{ transform: language === 'ar' ? 'translateX(0)' : 'none' }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-semibold mb-4">{t('contact.info.title')}</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-sm text-blue-100">
                <MapPin className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <span>{t('contact.info.address')}</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-blue-100">
                <Phone className="w-5 h-5 flex-shrink-0" />
                <span>{t('contact.info.phone')}</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-blue-100">
                <Mail className="w-5 h-5 flex-shrink-0" />
                <span>{t('contact.info.email')}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Newsletter */}
        <div className="border-t border-white/20 pt-8 mb-8">
          <div className="max-w-md mx-auto text-center">
            <h3 className="font-semibold mb-2">{t('footer.newsletter')}</h3>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder={t('footer.emailPlaceholder')}
                className="flex-1 px-4 py-2 rounded-lg bg-white/10 border border-white/20 text-white placeholder:text-blue-200 focus:outline-none focus:ring-2 focus:ring-white/30"
              />
              <button className="px-6 py-2 bg-white text-[#0059C8] font-medium rounded-lg hover:bg-blue-50 transition-colors whitespace-nowrap">
                {t('footer.subscribe')}
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/20 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-blue-100">
          <p>{t('footer.copyright')}</p>
          <div className="flex gap-6">
            <Link to="/terms" className="hover:text-white transition-colors">
              {t('footer.terms')}
            </Link>
            <Link to="/privacy" className="hover:text-white transition-colors">
              {t('footer.privacy')}
            </Link>
            <Link to="/cookies" className="hover:text-white transition-colors">
              {t('footer.cookies')}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
