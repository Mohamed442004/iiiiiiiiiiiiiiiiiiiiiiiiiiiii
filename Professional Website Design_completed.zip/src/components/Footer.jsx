import React from 'react';

export default function Footer(){
  return (
    <footer style={{padding:'2rem', borderTop:'1px solid #e6e6e6', textAlign:'center'}}>
      <div>© {new Date().getFullYear()} TechNova — All rights reserved.</div>
    </footer>
  );
}
