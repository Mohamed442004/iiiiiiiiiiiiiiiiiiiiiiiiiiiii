import { useEffect, useRef } from 'react';

export default function Hero3D() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let animationFrameId;
    let time = 0;

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Particle class for 3D-like floating elements
    class Particle {
      constructor() {
        this.reset();
      }

      reset() {
        this.x = Math.random() * canvas.offsetWidth;
        this.y = Math.random() * canvas.offsetHeight;
        this.z = Math.random() * 1000;
        this.size = Math.random() * 3 + 1;
        this.speedX = (Math.random() - 0.5) * 0.5;
        this.speedY = (Math.random() - 0.5) * 0.5;
        this.speedZ = Math.random() * 2 + 1;
      }

      update() {
        this.z -= this.speedZ;
        this.x += this.speedX;
        this.y += this.speedY;

        if (this.z < 1) {
          this.reset();
        }
      }

      draw() {
        const scale = 1000 / (1000 + this.z);
        const x = (this.x - canvas.offsetWidth / 2) * scale + canvas.offsetWidth / 2;
        const y = (this.y - canvas.offsetHeight / 2) * scale + canvas.offsetHeight / 2;
        const size = this.size * scale;

        const opacity = Math.min(1, (1000 - this.z) / 500);
        
        // Draw particle with glow
        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 192, 240, ${opacity * 0.6})`;
        ctx.fill();

        // Add glow effect
        ctx.beginPath();
        ctx.arc(x, y, size * 2, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 89, 200, ${opacity * 0.2})`;
        ctx.fill();
      }
    }

    // Create particles
    const particles = Array.from({ length: 80 }, () => new Particle());

    // Floating geometric shapes
    class FloatingShape {
      constructor(type) {
        this.type = type;
        this.x = Math.random() * canvas.offsetWidth;
        this.y = Math.random() * canvas.offsetHeight;
        this.size = Math.random() * 40 + 20;
        this.rotation = Math.random() * Math.PI * 2;
        this.rotationSpeed = (Math.random() - 0.5) * 0.02;
        this.speedX = (Math.random() - 0.5) * 0.3;
        this.speedY = (Math.random() - 0.5) * 0.3;
        this.opacity = Math.random() * 0.3 + 0.1;
      }

      update() {
        this.x += this.speedX;
        this.y += this.speedY;
        this.rotation += this.rotationSpeed;

        if (this.x < -100) this.x = canvas.offsetWidth + 100;
        if (this.x > canvas.offsetWidth + 100) this.x = -100;
        if (this.y < -100) this.y = canvas.offsetHeight + 100;
        if (this.y > canvas.offsetHeight + 100) this.y = -100;
      }

      draw() {
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);

        if (this.type === 'square') {
          ctx.strokeStyle = `rgba(0, 89, 200, ${this.opacity})`;
          ctx.lineWidth = 2;
          ctx.strokeRect(-this.size / 2, -this.size / 2, this.size, this.size);
        } else if (this.type === 'triangle') {
          ctx.beginPath();
          ctx.moveTo(0, -this.size / 2);
          ctx.lineTo(this.size / 2, this.size / 2);
          ctx.lineTo(-this.size / 2, this.size / 2);
          ctx.closePath();
          ctx.strokeStyle = `rgba(0, 192, 240, ${this.opacity})`;
          ctx.lineWidth = 2;
          ctx.stroke();
        } else if (this.type === 'circle') {
          ctx.beginPath();
          ctx.arc(0, 0, this.size / 2, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(31, 74, 122, ${this.opacity})`;
          ctx.lineWidth = 2;
          ctx.stroke();
        }

        ctx.restore();
      }
    }

    const shapes = [
      ...Array.from({ length: 5 }, () => new FloatingShape('square')),
      ...Array.from({ length: 5 }, () => new FloatingShape('triangle')),
      ...Array.from({ length: 5 }, () => new FloatingShape('circle')),
    ];

    // Wave effect
    const drawWaves = () => {
      const waveCount = 3;
      for (let i = 0; i < waveCount; i++) {
        ctx.beginPath();
        ctx.moveTo(0, canvas.offsetHeight / 2);

        for (let x = 0; x < canvas.offsetWidth; x += 5) {
          const y =
            canvas.offsetHeight / 2 +
            Math.sin((x + time * 2 + i * 100) * 0.01) * 30 +
            Math.cos((x + time * 1.5 + i * 150) * 0.008) * 20;
          ctx.lineTo(x, y);
        }

        ctx.strokeStyle = `rgba(0, 192, 240, ${0.1 - i * 0.03})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    };

    // Grid effect
    const drawGrid = () => {
      const gridSize = 50;
      const offsetX = (time * 0.5) % gridSize;
      const offsetY = (time * 0.3) % gridSize;

      ctx.strokeStyle = 'rgba(0, 89, 200, 0.05)';
      ctx.lineWidth = 1;

      // Vertical lines
      for (let x = -offsetX; x < canvas.offsetWidth; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.offsetHeight);
        ctx.stroke();
      }

      // Horizontal lines
      for (let y = -offsetY; y < canvas.offsetHeight; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.offsetWidth, y);
        ctx.stroke();
      }
    };

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);

      // Draw grid
      drawGrid();

      // Draw waves
      drawWaves();

      // Update and draw shapes
      shapes.forEach((shape) => {
        shape.update();
        shape.draw();
      });

      // Update and draw particles
      particles.forEach((particle) => {
        particle.update();
        particle.draw();
      });

      time += 1;
      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ mixBlendMode: 'screen' }}
    />
  );
}
