export const translations = {
  en: {
    // Navigation
    nav: {
      home: 'Home',
      about: 'About',
      services: 'Services',
      solutions: 'Solutions',
      portfolio: 'Portfolio',
      products: 'Products',
      pricing: 'Pricing',
      contact: 'Contact',
      login: 'Login',
      register: 'Register',
    },
    
    // Home Page
    home: {
      hero: {
        title: 'Transform Your Business with',
        titleHighlight: 'TechNova Solutions',
        subtitle: 'Leading IT services, innovative web development, and cutting-edge technology products for businesses that aim higher.',
        cta1: 'Get Started',
        cta2: 'View Services',
      },
      about: {
        title: 'Why Choose TechNova',
        subtitle: 'We deliver excellence through innovation, expertise, and commitment to your success',
        feature1Title: 'Expert Team',
        feature1Desc: 'Certified professionals with years of industry experience',
        feature2Title: 'Innovative Solutions',
        feature2Desc: 'Cutting-edge technology tailored to your business needs',
        feature3Title: '24/7 Support',
        feature3Desc: 'Round-the-clock technical support and assistance',
        feature4Title: 'Proven Track Record',
        feature4Desc: 'Successfully delivered 500+ projects across industries',
      },
      services: {
        title: 'Our Core Services',
        subtitle: 'Comprehensive IT solutions to power your business growth',
        service1: 'IT Consulting',
        service1Desc: 'Strategic technology planning and implementation guidance',
        service2: 'Web Development',
        service2Desc: 'Custom websites and web applications built for performance',
        service3: 'Cloud Solutions',
        service3Desc: 'Scalable cloud infrastructure and migration services',
        service4: 'Cybersecurity',
        service4Desc: 'Comprehensive security solutions to protect your assets',
      },
      stats: {
        title: 'TechNova by Numbers',
        clients: 'Happy Clients',
        projects: 'Projects Completed',
        support: 'Support Hours',
        satisfaction: 'Client Satisfaction',
      },
      cta: {
        title: 'Ready to Transform Your Business?',
        subtitle: 'Join hundreds of companies that trust TechNova for their IT needs',
        button: 'Contact Us Today',
      },
    },
    
    // About Page
    about: {
      hero: {
        title: 'About TechNova',
        subtitle: 'Your trusted partner in digital transformation and IT excellence',
      },
      mission: {
        title: 'Our Mission',
        text: 'At TechNova, we are committed to empowering businesses through innovative technology solutions. We believe that the right technology can transform operations, drive growth, and create lasting competitive advantages.',
      },
      vision: {
        title: 'Our Vision',
        text: 'To be the leading IT solutions provider in the region, recognized for excellence, innovation, and unwavering commitment to client success.',
      },
      values: {
        title: 'Our Values',
        value1: 'Excellence',
        value1Desc: 'We strive for excellence in everything we do',
        value2: 'Innovation',
        value2Desc: 'We embrace new technologies and creative solutions',
        value3: 'Integrity',
        value3Desc: 'We operate with honesty and transparency',
        value4: 'Partnership',
        value4Desc: 'We build long-term relationships with our clients',
      },
      story: {
        title: 'Our Story',
        text: 'Founded in 2018, TechNova has grown from a small team of passionate technologists to a full-service IT solutions provider. Today, we serve clients across multiple industries, delivering cutting-edge solutions that drive business success.',
      },
    },
    
    // Services Page
    services: {
      hero: {
        title: 'Our Services',
        subtitle: 'Comprehensive IT solutions designed to meet your business needs',
      },
      itConsulting: {
        title: 'IT Consulting',
        desc: 'Strategic technology planning and implementation to align IT with business goals',
        features: ['Technology Assessment', 'Digital Strategy', 'IT Roadmap', 'Vendor Management'],
      },
      webDevelopment: {
        title: 'Web Development',
        desc: 'Custom web solutions built with modern technologies for optimal performance',
        features: ['Custom Websites', 'E-commerce Platforms', 'Web Applications', 'CMS Development'],
      },
      cloudServices: {
        title: 'Cloud Solutions',
        desc: 'Scalable and secure cloud infrastructure to support your growth',
        features: ['Cloud Migration', 'Infrastructure Setup', 'Cloud Security', 'Managed Services'],
      },
      cybersecurity: {
        title: 'Cybersecurity',
        desc: 'Comprehensive security solutions to protect your digital assets',
        features: ['Security Audits', 'Threat Detection', 'Data Protection', 'Compliance'],
      },
      networkInfra: {
        title: 'Network Infrastructure',
        desc: 'Design, implementation, and management of reliable network systems',
        features: ['Network Design', 'Installation', 'Optimization', '24/7 Monitoring'],
      },
      dataAnalytics: {
        title: 'Data Analytics',
        desc: 'Transform data into actionable insights for better decision making',
        features: ['Business Intelligence', 'Data Visualization', 'Predictive Analytics', 'Reporting'],
      },
    },
    
    // Products
    products: {
      hero: {
        title: 'Our Products',
        subtitle: 'Premium IT and networking products from leading brands',
      },
      category: 'Category',
      price: 'Price',
      viewDetails: 'View Details',
      addToCart: 'Add to Cart',
      specifications: 'Specifications',
      features: 'Features',
      description: 'Description',
      relatedProducts: 'Related Products',
    },
    
    // Pricing
    pricing: {
      hero: {
        title: 'Pricing Plans',
        subtitle: 'Choose the perfect plan for your business needs',
      },
      monthly: 'Monthly',
      yearly: 'Yearly',
      perMonth: '/month',
      selectPlan: 'Select Plan',
      popular: 'Most Popular',
      starter: {
        name: 'Starter',
        price: '$299',
        desc: 'Perfect for small businesses',
        features: ['Basic IT Support', '5 User Licenses', 'Email Support', 'Monthly Reports', 'Security Updates'],
      },
      professional: {
        name: 'Professional',
        price: '$799',
        desc: 'Ideal for growing companies',
        features: ['Priority Support', '25 User Licenses', 'Phone & Email Support', 'Weekly Reports', 'Advanced Security', 'Cloud Backup'],
      },
      enterprise: {
        name: 'Enterprise',
        price: 'Custom',
        desc: 'For large organizations',
        features: ['24/7 Dedicated Support', 'Unlimited Users', 'Custom Solutions', 'Real-time Analytics', 'Enterprise Security', 'Custom Integration', 'SLA Guarantee'],
      },
    },
    
    // Contact
    contact: {
      hero: {
        title: 'Contact Us',
        subtitle: 'Get in touch with our team of experts',
      },
      form: {
        name: 'Full Name',
        email: 'Email Address',
        phone: 'Phone Number',
        subject: 'Subject',
        message: 'Message',
        send: 'Send Message',
      },
      info: {
        title: 'Contact Information',
        address: '123 Business District, Tech Tower, Cairo, Egypt',
        phone: '+20 123 456 7890',
        email: 'info@technova.com',
        hours: 'Mon - Fri: 9:00 AM - 6:00 PM',
      },
    },
    
    // Auth
    auth: {
      login: {
        title: 'Login to TechNova',
        subtitle: 'Welcome back! Please login to your account',
        email: 'Email Address',
        password: 'Password',
        remember: 'Remember me',
        forgot: 'Forgot Password?',
        submit: 'Login',
        noAccount: "Don't have an account?",
        signup: 'Sign up',
        or: 'OR',
        google: 'Continue with Google',
      },
      register: {
        title: 'Create Account',
        subtitle: 'Join TechNova and start your journey',
        fullName: 'Full Name',
        email: 'Email Address',
        phone: 'Phone Number',
        password: 'Password',
        confirmPassword: 'Confirm Password',
        agree: 'I agree to the Terms & Conditions',
        submit: 'Create Account',
        hasAccount: 'Already have an account?',
        signin: 'Sign in',
        google: 'Sign up with Google',
      },
      verification: {
        title: 'Google Verification',
        subtitle: 'Enter the verification code sent to your Gmail',
        code: 'Verification Code',
        verify: 'Verify',
        resend: 'Resend Code',
        didntReceive: "Didn't receive the code?",
      },
    },
    
    // Payment
    payment: {
      title: 'Payment Details',
      subtitle: 'Complete your purchase securely',
      orderSummary: 'Order Summary',
      subtotal: 'Subtotal',
      tax: 'Tax',
      total: 'Total',
      method: 'Payment Method',
      cardNumber: 'Card Number',
      cardName: 'Cardholder Name',
      expiry: 'Expiry Date',
      cvv: 'CVV',
      pay: 'Complete Payment',
      secure: 'Your payment information is secure and encrypted',
    },
    
    // Footer
    footer: {
      tagline: 'Empowering businesses through innovative technology solutions',
      quickLinks: 'Quick Links',
      services: 'Services',
      company: 'Company',
      legal: 'Legal',
      terms: 'Terms of Service',
      privacy: 'Privacy Policy',
      cookies: 'Cookie Policy',
      followUs: 'Follow Us',
      newsletter: 'Subscribe to our newsletter',
      emailPlaceholder: 'Enter your email',
      subscribe: 'Subscribe',
      copyright: '© 2025 TechNova. All rights reserved.',
    },
  },
  
  ar: {
    // Navigation
    nav: {
      home: 'الرئيسية',
      about: 'من نحن',
      services: 'الخدمات',
      solutions: 'الحلول',
      portfolio: 'معرض الأعمال',
      products: 'المنتجات',
      pricing: 'الأسعار',
      contact: 'اتصل بنا',
      login: 'تسجيل الدخول',
      register: 'إنشاء حساب',
    },
    
    // Home Page
    home: {
      hero: {
        title: 'حوّل عملك مع',
        titleHighlight: 'حلول تك نوفا',
        subtitle: 'خدمات تقنية معلومات رائدة، تطوير ويب مبتكر، ومنتجات تكنولوجية متطورة للشركات التي تهدف للأعلى.',
        cta1: 'ابدأ الآن',
        cta2: 'استعرض الخدمات',
      },
      about: {
        title: 'لماذا تختار تك نوفا',
        subtitle: 'نقدم التميز من خلال الابتكار والخبرة والالتزام بنجاحك',
        feature1Title: 'فريق خبراء',
        feature1Desc: 'متخصصون معتمدون بخبرة سنوات في الصناعة',
        feature2Title: 'حلول مبتكرة',
        feature2Desc: 'تكنولوجيا متطورة مصممة خصيصاً لاحتياجات عملك',
        feature3Title: 'دعم على مدار الساعة',
        feature3Desc: 'دعم فني ومساعدة على مدار الساعة طوال أيام الأسبوع',
        feature4Title: 'سجل حافل بالنجاح',
        feature4Desc: 'أكثر من 500 مشروع ناجح عبر مختلف الصناعات',
      },
      services: {
        title: 'خدماتنا الأساسية',
        subtitle: 'حلول تقنية شاملة لدعم نمو عملك',
        service1: 'استشارات تقنية',
        service1Desc: 'تخطيط استراتيجي للتكنولوجيا وإرشادات التنفيذ',
        service2: 'تطوير الويب',
        service2Desc: 'مواقع وتطبيقات ويب مخصصة مبنية للأداء',
        service3: 'الحلول السحابية',
        service3Desc: 'بنية تحتية سحابية قابلة للتوسع وخدمات الترحيل',
        service4: 'الأمن السيبراني',
        service4Desc: 'حلول أمنية شاملة لحماية أصولك',
      },
      stats: {
        title: 'تك نوفا بالأرقام',
        clients: 'عميل سعيد',
        projects: 'مشروع مكتمل',
        support: 'ساعة دعم',
        satisfaction: 'رضا العملاء',
      },
      cta: {
        title: 'هل أنت مستعد لتحويل عملك؟',
        subtitle: 'انضم لمئات الشركات التي تثق بتك نوفا لاحتياجاتها التقنية',
        button: 'تواصل معنا اليوم',
      },
    },
    
    // About Page
    about: {
      hero: {
        title: 'عن تك نوفا',
        subtitle: 'شريكك الموثوق في التحول الرقمي والتميز التقني',
      },
      mission: {
        title: 'مهمتنا',
        text: 'في تك نوفا، نحن ملتزمون بتمكين الشركات من خلال حلول تقنية مبتكرة. نؤمن بأن التكنولوجيا الصحيحة يمكن أن تحول العمليات، وتدفع النمو، وتخلق ميزات تنافسية دائمة.',
      },
      vision: {
        title: 'رؤيتنا',
        text: 'أن نكون مزود الحلول التقنية الرائد في المنطقة، معترف به للتميز والابتكار والالتزام الثابت بنجاح العملاء.',
      },
      values: {
        title: 'قيمنا',
        value1: 'التميز',
        value1Desc: 'نسعى للتميز في كل ما نقوم به',
        value2: 'الابتكار',
        value2Desc: 'نتبنى التقنيات الجديدة والحلول الإبداعية',
        value3: 'النزاهة',
        value3Desc: 'نعمل بصدق وشفافية',
        value4: 'الشراكة',
        value4Desc: 'نبني علاقات طويلة الأمد مع عملائنا',
      },
      story: {
        title: 'قصتنا',
        text: 'تأسست تك نوفا في 2018، ونمت من فريق صغير من التقنيين المتحمسين إلى مزود خدمات تقنية متكامل. اليوم، نخدم عملاء في مختلف الصناعات، نقدم حلول متطورة تدفع نجاح الأعمال.',
      },
    },
    
    // Services Page
    services: {
      hero: {
        title: 'خدماتنا',
        subtitle: 'حلول تقنية شاملة مصممة لتلبية احتياجات عملك',
      },
      itConsulting: {
        title: 'استشارات تقنية المعلومات',
        desc: 'تخطيط وتنفيذ استراتيجي للتكنولوجيا لمواءمة تقنية المعلومات مع أهداف العمل',
        features: ['تقييم التكنولوجيا', 'الاستراتيجية الرقمية', 'خارطة طريق تقنية', 'إدارة الموردين'],
      },
      webDevelopment: {
        title: 'تطوير الويب',
        desc: 'حلول ويب مخصصة مبنية بتقنيات حديثة للأداء الأمثل',
        features: ['مواقع مخصصة', 'منصات تجارة إلكترونية', 'تطبيقات ويب', 'تطوير أنظمة إدارة المحتوى'],
      },
      cloudServices: {
        title: 'الحلول السحابية',
        desc: 'بنية تحتية سحابية قابلة للتوسع وآمنة لدعم نموك',
        features: ['الترحيل السحابي', 'إعداد البنية التحتية', 'الأمن السحابي', 'الخدمات المدارة'],
      },
      cybersecurity: {
        title: 'الأمن السيبراني',
        desc: 'حلول أمنية شاملة لحماية أصولك الرقمية',
        features: ['عمليات التدقيق الأمني', 'كشف التهديدات', 'حماية البيانات', 'الامتثال'],
      },
      networkInfra: {
        title: 'البنية التحتية للشبكات',
        desc: 'تصميم وتنفيذ وإدارة أنظمة شبكات موثوقة',
        features: ['تصميم الشبكة', 'التركيب', 'التحسين', 'مراقبة على مدار الساعة'],
      },
      dataAnalytics: {
        title: 'تحليل البيانات',
        desc: 'تحويل البيانات إلى رؤى قابلة للتنفيذ لاتخاذ قرارات أفضل',
        features: ['ذكاء الأعمال', 'تصور البيانات', 'التحليلات التنبؤية', 'التقارير'],
      },
    },
    
    // Products
    products: {
      hero: {
        title: 'منتجاتنا',
        subtitle: 'منتجات تقنية معلومات وشبكات متميزة من علامات تجارية رائدة',
      },
      category: 'الفئة',
      price: 'السعر',
      viewDetails: 'عرض التفاصيل',
      addToCart: 'أضف للسلة',
      specifications: 'المواصفات',
      features: 'المميزات',
      description: 'الوصف',
      relatedProducts: 'منتجات ذات صلة',
    },
    
    // Pricing
    pricing: {
      hero: {
        title: 'خطط الأسعار',
        subtitle: 'اختر الخطة المثالية لاحتياجات عملك',
      },
      monthly: 'شهري',
      yearly: 'سنوي',
      perMonth: '/شهر',
      selectPlan: 'اختر الخطة',
      popular: 'الأكثر شعبية',
      starter: {
        name: 'المبتدئ',
        price: '299 دولار',
        desc: 'مثالي للشركات الصغيرة',
        features: ['دعم تقني أساسي', '5 تراخيص مستخدم', 'دعم عبر البريد', 'تقارير شهرية', 'تحديثات أمنية'],
      },
      professional: {
        name: 'المحترف',
        price: '799 دولار',
        desc: 'مثالي للشركات النامية',
        features: ['دعم أولوية', '25 ترخيص مستخدم', 'دعم هاتفي وبريد', 'تقارير أسبوعية', 'أمان متقدم', 'نسخ احتياطي سحابي'],
      },
      enterprise: {
        name: 'المؤسسات',
        price: 'مخصص',
        desc: 'للمؤسسات الكبيرة',
        features: ['دعم مخصص 24/7', 'مستخدمين غير محدودين', 'حلول مخصصة', 'تحليلات فورية', 'أمان المؤسسات', 'تكامل مخصص', 'ضمان SLA'],
      },
    },
    
    // Contact
    contact: {
      hero: {
        title: 'اتصل بنا',
        subtitle: 'تواصل مع فريق الخبراء لدينا',
      },
      form: {
        name: 'الاسم الكامل',
        email: 'البريد الإلكتروني',
        phone: 'رقم الهاتف',
        subject: 'الموضوع',
        message: 'الرسالة',
        send: 'إرسال الرسالة',
      },
      info: {
        title: 'معلومات الاتصال',
        address: '123 منطقة الأعمال، برج التكنولوجيا، القاهرة، مصر',
        phone: '7890 456 123 20+',
        email: 'info@technova.com',
        hours: 'الإثنين - الجمعة: 9:00 صباحاً - 6:00 مساءً',
      },
    },
    
    // Auth
    auth: {
      login: {
        title: 'تسجيل الدخول إلى تك نوفا',
        subtitle: 'مرحباً بعودتك! يرجى تسجيل الدخول إلى حسابك',
        email: 'البريد الإلكتروني',
        password: 'كلمة المرور',
        remember: 'تذكرني',
        forgot: 'نسيت كلمة المرور؟',
        submit: 'تسجيل الدخول',
        noAccount: 'ليس لديك حساب؟',
        signup: 'إنشاء حساب',
        or: 'أو',
        google: 'متابعة باستخدام Google',
      },
      register: {
        title: 'إنشاء حساب',
        subtitle: 'انضم إلى تك نوفا وابدأ رحلتك',
        fullName: 'الاسم الكامل',
        email: 'البريد الإلكتروني',
        phone: 'رقم الهاتف',
        password: 'كلمة المرور',
        confirmPassword: 'تأكيد كلمة المرور',
        agree: 'أوافق على الشروط والأحكام',
        submit: 'إنشاء حساب',
        hasAccount: 'هل لديك حساب؟',
        signin: 'تسجيل الدخول',
        google: 'التسجيل باستخدام Google',
      },
      verification: {
        title: 'التحقق من Google',
        subtitle: 'أدخل رمز التحقق المرسل إلى Gmail الخاص بك',
        code: 'رمز التحقق',
        verify: 'تحقق',
        resend: 'إعادة إرسال الرمز',
        didntReceive: 'لم تستلم الرمز؟',
      },
    },
    
    // Payment
    payment: {
      title: 'تفاصيل الدفع',
      subtitle: 'أكمل عملية الشراء بشكل آمن',
      orderSummary: 'ملخص الطلب',
      subtotal: 'المجموع الفرعي',
      tax: 'الضريبة',
      total: 'الإجمالي',
      method: 'طريقة الدفع',
      cardNumber: 'رقم البطاقة',
      cardName: 'اسم حامل البطاقة',
      expiry: 'تاريخ الانتهاء',
      cvv: 'CVV',
      pay: 'إتمام الدفع',
      secure: 'معلومات الدفع الخاصة بك آمنة ومشفرة',
    },
    
    // Footer
    footer: {
      tagline: 'تمكين الشركات من خلال حلول تقنية مبتكرة',
      quickLinks: 'روابط سريعة',
      services: 'الخدمات',
      company: 'الشركة',
      legal: 'قانوني',
      terms: 'شروط الخدمة',
      privacy: 'سياسة الخصوصية',
      cookies: 'سياسة ملفات تعريف الارتباط',
      followUs: 'تابعنا',
      newsletter: 'اشترك في نشرتنا الإخبارية',
      emailPlaceholder: 'أدخل بريدك الإلكتروني',
      subscribe: 'اشترك',
      copyright: '© 2025 تك نوفا. جميع الحقوق محفوظة.',
    },
  },
};

export const getTranslation = (language, key) => {
  const keys = key.split('.');
  let value = translations[language];
  
  for (const k of keys) {
    value = value?.[k];
  }
  
  return value || key;
};
